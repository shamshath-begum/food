# FoodShare Connect (Full Stack)

A minimal, mobile-friendly app that connects people who have excess food with those who need it.

## Tech
- Frontend: HTML, CSS, vanilla JS (responsive)
- Backend: Node.js (Express)
- Database: MongoDB (Mongoose)

## Quick Start (Local)
1) Install Node.js and MongoDB. Start MongoDB locally.
2) Open a terminal and run:
```bash
cd backend
cp .env.example .env
npm install
npm run seed:admin   # creates the admin user defined in .env
npm run start
```
The API runs at http://localhost:4000/api

3) Open `frontend/index.html` in your browser for the UI. It points to the API at http://localhost:4000/api by default.

## Admin
- Visit `frontend/admin.html`, login using the seeded admin phone/password, then you can view stats and manage donations/users.

## Notes
- Collectors must login to reveal donor contact details.
- Donors must login to post donations.
