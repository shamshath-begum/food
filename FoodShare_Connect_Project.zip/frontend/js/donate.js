const form = document.getElementById('donateForm');
const msg = document.getElementById('donateMsg');

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const user = getUser();
  if(!user || (user.role !== 'donor' && user.role !== 'admin')){
    msg.textContent = 'Please login as a Donor to post.';
    return;
  }
  const payload = Object.fromEntries(new FormData(form).entries());
  const res = await fetch(`${API_BASE}/donations`, {
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization': 'Bearer ' + getToken()
    },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if(data.ok){
    msg.textContent = 'Donation posted!';
    form.reset();
  } else {
    msg.textContent = data.error || 'Failed to post donation';
  }
});
