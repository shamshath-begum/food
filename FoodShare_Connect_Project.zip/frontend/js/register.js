document.getElementById('registerForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const form = new FormData(e.target);
  const payload = Object.fromEntries(form.entries());
  const res = await fetch(`${API_BASE}/auth/register`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  const msg = document.getElementById('registerMsg');
  if(data.ok){
    msg.textContent = 'Registration successful! Please login.';
    setTimeout(()=> location.href = 'login.html', 800);
  } else {
    msg.textContent = data.error || 'Registration failed';
  }
});
