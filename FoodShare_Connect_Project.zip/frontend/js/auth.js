const API_BASE = localStorage.getItem('API_BASE') || 'http://localhost:4000/api';

function saveSession(user, token){
  localStorage.setItem('user', JSON.stringify(user));
  localStorage.setItem('token', token);
  updateNav();
}

function getUser(){ const u = localStorage.getItem('user'); return u ? JSON.parse(u) : null; }
function getToken(){ return localStorage.getItem('token'); }

function updateNav(){
  const u = getUser();
  const login = document.getElementById('navLogin');
  const reg = document.getElementById('navRegister');
  const out = document.getElementById('logoutBtn');
  if(out){
    out.style.display = u ? 'inline-flex' : 'none';
    out.onclick = () => { localStorage.removeItem('user'); localStorage.removeItem('token'); updateNav(); location.href='index.html'; };
  }
  if(login) login.style.display = u ? 'none' : 'inline-flex';
  if(reg) reg.style.display = u ? 'none' : 'inline-flex';
}

document.addEventListener('DOMContentLoaded', updateNav);
