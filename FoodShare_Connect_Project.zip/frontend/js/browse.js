const listEl = document.getElementById('list');
const msg = document.getElementById('browseMsg');

async function load(){
  const loc = document.getElementById('filterLocation').value.trim();
  const type = document.getElementById('filterType').value.trim();
  const params = new URLSearchParams();
  if(loc) params.set('location', loc);
  if(type) params.set('type', type);
  const role = (getUser()?.role) || '';
  const res = await fetch(`${API_BASE}/donations?${params.toString()}`, { headers: { 'x-role': role } });
  const data = await res.json();
  if(!data.ok) { msg.textContent = data.error || 'Failed to load'; return; }
  render(data.donations);
}

function render(items){
  listEl.innerHTML = '';
  if(!items.length){
    listEl.innerHTML = '<p>No donations found. Try different filters.</p>';
    return;
  }
  for(const d of items){
    const div = document.createElement('div');
    div.className = 'card';
    const exp = new Date(d.expiryTime);
    div.innerHTML = `
      <h3>${d.foodType}</h3>
      <p><strong>Qty:</strong> ${d.quantity}</p>
      <p><strong>Pickup:</strong> ${d.pickupLocation}</p>
      <p><strong>Expires:</strong> ${exp.toLocaleString()}</p>
      <p><em>Donor:</em> ${d.donor?.name || 'Donor'}</p>
      <p><em>Contact:</em> ${d.donor?.phone ? d.donor.phone : (d.donor?.phoneMasked || 'Login as collector to view')}</p>
      <div style="display:flex; gap:8px; flex-wrap:wrap">
        <button class="btn secondary" data-id="${d.id}">Contact</button>
      </div>
    `;
    const btn = div.querySelector('button');
    btn.onclick = async () => {
      const u = getUser();
      if(!u || (u.role!=='collector' && u.role!=='admin')){
        alert('Please login as a collector to reveal contact info.');
        return;
      }
      const res = await fetch(`${API_BASE}/donations/${d.id}/contact`, {
        headers: { 'Authorization': 'Bearer ' + getToken() }
      });
      const data = await res.json();
      if(data.ok){
        alert(`Donor: ${data.donor.name}\nPhone: ${data.donor.phone}`);
      } else {
        alert(data.error || 'Failed');
      }
    };
    listEl.appendChild(div);
  }
}

document.getElementById('applyFilters').addEventListener('click', load);
document.addEventListener('DOMContentLoaded', load);
