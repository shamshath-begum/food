async function mustAdmin(){
  const u = getUser();
  if(!u || u.role!=='admin'){ alert('Admin only.'); location.href='login.html'; }
}
async function loadStats(){
  const res = await fetch(`${API_BASE}/admin/stats`, {
    headers: { 'Authorization': 'Bearer ' + getToken() }
  });
  const data = await res.json();
  if(data.ok){ document.getElementById('stats').textContent = JSON.stringify(data.stats,null,2); }
}
async function loadDonations(){
  const res = await fetch(`${API_BASE}/admin/donations`, {
    headers: { 'Authorization': 'Bearer ' + getToken() }
  });
  const data = await res.json();
  const wrap = document.getElementById('adminDonations');
  if(!data.ok){ wrap.innerHTML = 'Failed'; return; }
  wrap.innerHTML = '';
  for(const d of data.donations){
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `
      <h4>${d.foodType}</h4>
      <p>${d.quantity} · ${new Date(d.expiryTime).toLocaleString()}</p>
      <p><em>${d.pickupLocation}</em></p>
      <p>Status: <strong>${d.status}</strong></p>
      <div style="display:flex; gap:6px; flex-wrap:wrap">
        ${['available','claimed','expired'].map(s=>`<button class="btn small" data-s="${s}" data-id="${d._id}">${s}</button>`).join('')}
        <button class="btn small outline" data-del="${d._id}">Delete</button>
      </div>
    `;
    div.querySelectorAll('button[data-s]').forEach(b => {
      b.onclick = async () => {
        await fetch(`${API_BASE}/donations/${b.dataset.id}/status`, {
          method:'PATCH',
          headers:{
            'Content-Type':'application/json',
            'Authorization': 'Bearer ' + getToken()
          },
          body: JSON.stringify({ status: b.dataset.s })
        });
        loadDonations();
      };
    });
    div.querySelector('button[data-del]').onclick = async (ev)=>{
      const id = ev.target.dataset.del;
      await fetch(`${API_BASE}/donations/${id}`, {
        method:'DELETE',
        headers:{ 'Authorization': 'Bearer ' + getToken() }
      });
      loadDonations();
    };
    wrap.appendChild(div);
  }
}
async function loadUsers(){
  const res = await fetch(`${API_BASE}/admin/users`, {
    headers: { 'Authorization': 'Bearer ' + getToken() }
  });
  const data = await res.json();
  if(!data.ok) return;
  const el = document.getElementById('adminUsers');
  el.innerHTML = '<ul>' + data.users.map(u=>`<li>${u.name} · ${u.role} · ${u.phone}</li>`).join('') + '</ul>';
}
document.addEventListener('DOMContentLoaded', async ()=>{
  await mustAdmin();
  await loadStats(); await loadDonations(); await loadUsers();
});
