document.getElementById('loginForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const form = new FormData(e.target);
  const payload = Object.fromEntries(form.entries());
  const res = await fetch(`${API_BASE}/auth/login`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  const msg = document.getElementById('loginMsg');
  if(data.ok){
    saveSession(data.user, data.token);
    msg.textContent = 'Login successful!';
    setTimeout(()=> location.href = 'index.html', 600);
  } else {
    msg.textContent = data.error || 'Login failed';
  }
});
