import mongoose from 'mongoose';

const donationSchema = new mongoose.Schema({
  donor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  foodType: { type: String, required: true },
  quantity: { type: String, required: true },
  expiryTime: { type: Date, required: true },
  pickupLocation: { type: String, required: true },
  notes: { type: String },
  status: { type: String, enum: ['available','claimed','expired','deleted'], default: 'available' },
  createdAt: { type: Date, default: Date.now }
});

donationSchema.index({ foodType: 'text', pickupLocation: 'text' });

export default mongoose.model('Donation', donationSchema);
