import dotenv from 'dotenv';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';

dotenv.config();

async function run(){
  const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/foodshare_connect';
  await mongoose.connect(uri);
  const { ADMIN_NAME, ADMIN_PHONE, ADMIN_LOCATION, ADMIN_PASSWORD } = process.env;
  if(!ADMIN_PHONE || !ADMIN_PASSWORD) {
    console.error('Missing ADMIN_* env vars');
    process.exit(1);
  }
  let admin = await User.findOne({ phone: ADMIN_PHONE });
  if(admin){
    console.log('Admin already exists:', admin.phone);
  } else {
    const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    admin = await User.create({
      name: ADMIN_NAME || 'Admin',
      phone: ADMIN_PHONE,
      location: ADMIN_LOCATION || 'HQ',
      role: 'admin',
      passwordHash
    });
    console.log('Admin created:', admin.phone);
  }
  process.exit(0);
}
run();
