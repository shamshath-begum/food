import express from 'express';
import { requireAuth } from '../middleware/auth.js';
import Donation from '../models/Donation.js';
import User from '../models/User.js';

const router = express.Router();

router.get('/stats', requireAuth(['admin']), async (req,res)=>{
  const totalUsers = await User.countDocuments();
  const donors = await User.countDocuments({ role: 'donor' });
  const collectors = await User.countDocuments({ role: 'collector' });
  const donations = await Donation.countDocuments();
  const available = await Donation.countDocuments({ status: 'available' });
  const claimed = await Donation.countDocuments({ status: 'claimed' });
  res.json({ ok:true, stats: { totalUsers, donors, collectors, donations, available, claimed } });
});

router.get('/donations', requireAuth(['admin']), async (req,res)=>{
  const list = await Donation.find().sort({ createdAt: -1 }).populate('donor','name phone location');
  res.json({ ok:true, donations: list });
});

router.get('/users', requireAuth(['admin']), async (req,res)=>{
  const list = await User.find().sort({ createdAt: -1 });
  res.json({ ok:true, users: list });
});

export default router;
