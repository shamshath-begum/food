import express from 'express';
import Donation from '../models/Donation.js';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// Create donation (donor)
router.post('/', requireAuth(['donor','admin']), async (req,res)=>{
  try {
    const { foodType, quantity, expiryTime, pickupLocation, notes } = req.body;
    const donation = await Donation.create({
      donor: req.user._id, foodType, quantity, expiryTime, pickupLocation, notes
    });
    res.json({ ok:true, donation });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// List donations with optional filters
router.get('/', async (req,res)=>{
  try {
    const { location, type, status='available' } = req.query;
    const q = { status };
    if(location) q.pickupLocation = { $regex: location, $options: 'i' };
    if(type) q.foodType = { $regex: type, $options: 'i' };
    const donations = await Donation.find(q).sort({ createdAt: -1 }).populate('donor','name phone location');

    const authRole = req.headers['x-role'] || null;
    const hideContact = !(authRole === 'collector' || authRole === 'admin');

    const data = donations.map(d => ({
      id: d._id,
      foodType: d.foodType,
      quantity: d.quantity,
      expiryTime: d.expiryTime,
      pickupLocation: d.pickupLocation,
      notes: d.notes,
      status: d.status,
      donor: {
        name: d.donor?.name ?? 'Donor',
        location: d.donor?.location ?? '',
        phone: hideContact ? null : d.donor?.phone ?? null,
        phoneMasked: d.donor?.phone ? d.donor.phone[:2] + "*******" + d.donor.phone[-2:] : null
      },
      createdAt: d.createdAt
    }));
    res.json({ ok:true, donations: data });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Reveal contact for a donation (collector only)
router.get('/:id/contact', requireAuth(['collector','admin']), async (req,res)=>{
  const id = req.params.id;
  const d = await Donation.findById(id).populate('donor','name phone');
  if(!d) return res.status(404).json({ error: 'Not found' });
  res.json({ ok:true, donor: { name: d.donor.name, phone: d.donor.phone } });
});

// Mark claimed/expired (admin or owner donor)
router.patch('/:id/status', requireAuth(['donor','admin']), async (req,res)=>{
  const id = req.params.id;
  const { status } = req.body;
  const allowed = ['available','claimed','expired','deleted'];
  if(!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const d = await Donation.findById(id);
  if(!d) return res.status(404).json({ error: 'Not found' });
  if(req.user.role !== 'admin' && d.donor.toString() !== req.user._id.toString())
    return res.status(403).json({ error: 'Forbidden' });
  d.status = status;
  await d.save();
  res.json({ ok:true, donation: d });
});

// Delete (admin or owner)
router.delete('/:id', requireAuth(['donor','admin']), async (req,res)=>{
  const id = req.params.id;
  const d = await Donation.findById(id);
  if(!d) return res.status(404).json({ error: 'Not found' });
  if(req.user.role !== 'admin' && d.donor.toString() !== req.user._id.toString())
    return res.status(403).json({ error: 'Forbidden' });
  await d.deleteOne();
  res.json({ ok:true });
});

export default router;
