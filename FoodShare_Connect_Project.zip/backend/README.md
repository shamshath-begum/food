# FoodShare Connect - Backend
## Setup
1. Copy `.env.example` to `.env` and edit values.
2. Install dependencies: `npm install`
3. (Optional) Seed admin user: `npm run seed:admin`
4. Start server: `npm run dev` (or `npm start`)
API runs on `http://localhost:4000` by default.
